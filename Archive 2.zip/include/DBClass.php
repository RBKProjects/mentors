<?php 
class DBClass { 
    // Properties
    public $host  = ''; 
    public $db_name = ''; 
    public $db_user = ''; 
    public $db_password = ''; 
    
    // Methods
    function openConnection($mentor) { 
       
    } 


    function closeConnection(){

    }
} 
?>


