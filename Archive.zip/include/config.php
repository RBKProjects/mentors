<?php
    // Database Infomation

    // Remote
    define("SERVER", "localhost");
    define("DB_USERNAME", "rbk15109_mentor");
    define("DB_PASSWORD", "5XzA4P*.7_E7");
    // Local
    // define("DB_USERNAME", "root");
    // define("DB_PASSWORD", "");
    // define("DB_NAME", "rbk.org:rbk15109_mentorship");
    define("DB_NAME", "rbk15109_mentorship");


    // define("SERVER", "181.224.138.180");
    // define("SERVER", "rbk.org");
?>
